package pl.sdacademy.petclinic.model;

import lombok.Data;

@Data
public class FilterForm {
	private String lastName;
}
